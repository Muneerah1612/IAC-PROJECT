def lambda_handler(event, context):
    message = 'Hello First Ansible Deployment!'
    return message